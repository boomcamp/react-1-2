import React from 'react';

export default function Product(props){
    return (

            props.products.map(prod => {
                return (
                    <div className="product">
                    <img src={prod.imageUrl} alt=""/>
                    <div className="product-info">
                        <h4>{prod.title}</h4>
                        <p>{prod.description}</p>
                        <p>{prod.price}</p>
                        <button onClick={() => this.props.addToCart(prod)}> Add to cart </button>
                    </div>   
                </div>
                )
            })

    )
}